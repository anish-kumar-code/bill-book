const mongoose = require("mongoose");

const collegeSchema = new mongoose.Schema({
    name: { type: String, default: "" },
    email: { type: String, default: "" },
    mobileNo: { type: String, default: "" },
    collegeName: { type: String, default: "" },
    category: { type: String, default: "" },
    collegeCode: { type: String, default: "" },
    collegeLogo: { type: String, default: "" },
    collegeId: { type: String, default: "" },
    collegeIdUnique: { type: String, default: "" },
    password: { type: String, default: "" },
    description: { type: String, default: "" },

    address: { type: String, default: "" },
    city: { type: String, default: "" },
    state: { type: String, default: "" },
    pincode: { type: String, default: "" },
    website: { type: String, default: "" },
    contactPerson: { type: String, default: "" },

    aboutUs: { type: String, default: "" },
    aboutUsImage: { type: String, default: "" },

    directorName: { type: String, default: "" },
    directorImage: { type: String, default: "" },
    directorMessage: { type: String, default: "" },

    registrationImage: { type: String, default: "" },

    galleryImages: { type: [String], default: [] },
    classroomImages: { type: [String], default: [] },
    libraryImages: { type: [String], default: [] },
    libraryDescription: { type: String, default: "" },
    labImages: { type: [String], default: [] },
    sportsImages: { type: [String], default: [] },
    hostelImages: { type: [String], default: [] },
    cafeteriaImages: { type: [String], default: [] },

    courses: { type: [String], default: [] },
    departments: { type: [String], default: [] },
    admissionProcess: { type: String, default: "" },
    feeStructure: { type: String, default: "" },

    achievements: { type: [String], default: [] },
    events: {
        type: [{
            title: { type: String, default: "" },
            description: { type: String, default: "" },
            date: Date,
            image: { type: String, default: "" }
        }],
        default: []
    },
    placementInfo: {
        description: { type: String, default: "" },
        stats: { type: Object, default: {} },
        image: { type: String, default: "" }
    },

    paymentStatus: { type: String, enum: ["pending", "completed"], default: "pending" },
    status: { type: String, enum: ["profilePending", "profileCompleted", "active", "inactive"], default: "profilePending" },
    callStatus: {
        type: String,
        enum: [
            "pending",          // Call not yet made
            "in progress",      // Currently in conversation / attempting
            "call done",        // Call completed successfully
            "next day call",    // Follow-up scheduled for next day
            "no answer",        // Call attempted, but no response
            "not interested",   // Lead declined interest
            "inactive"          // Lead dropped / archived
        ],
        default: "pending"
    },
    callDescription: { type: String, default: "" },

    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("College", collegeSchema);
