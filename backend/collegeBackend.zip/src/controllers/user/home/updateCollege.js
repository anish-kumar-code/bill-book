const College = require("../../../models/college");
const AppError = require("../../../utils/AppError");
const catchAsync = require("../../../utils/catchAsync");

exports.updateCollege = catchAsync(async (req, res, next) => {
    const collegeId = req.params.collegeId
    const updateData = req.body;

    const college = await College.findById(collegeId);
    if (!college) {
        return next(new AppError("College not found", 404));
    }

    // Handle image uploads
    if (req.files && req.files.collegeLogo && req.files.collegeLogo.length > 0) {
        const uploadedPath = `${req.files.collegeLogo[0].destination}/${req.files.collegeLogo[0].filename}`;
        college.collegeLogo = uploadedPath;
    }

    if (req.files && req.files.directorImage && req.files.directorImage.length > 0) {
        const uploadedPath = `${req.files.directorImage[0].destination}/${req.files.directorImage[0].filename}`;
        college.directorImage = uploadedPath;
    }

    if (req.files && req.files.aboutImage && req.files.aboutImage.length > 0) {
        const uploadedPath = `${req.files.aboutImage[0].destination}/${req.files.aboutImage[0].filename}`;
        college.aboutUsImage = uploadedPath;
    }

    if (req.files && req.files.registrationImage && req.files.registrationImage.length > 0) {
        const uploadedPath = `${req.files.registrationImage[0].destination}/${req.files.registrationImage[0].filename}`;
        college.registrationImage = uploadedPath;
    }

    // List of allowed fields to update
    const allowedFields = [
        "name", "email", "mobileNo", "collegeName", "category", "collegeCode",
        "address", "city", "state", "pincode", "website", "contactPerson",
        "aboutUs", "directorName", "directorMessage", "libraryDescription",
        "admissionProcess", "feeStructure", "callStatus", "callDescription"
    ];

    allowedFields.forEach(field => {
        if (updateData[field] !== undefined) {
            college[field] = updateData[field];
        }
    });

    // Optional: mark profile as completed if basic info filled
    if (college.name && college.collegeName && college.collegeLogo) {
        college.status = "profileCompleted";
    }

    await college.save();

    res.status(200).json({
        status: true,
        message: "College profile updated successfully",
        data: college
    });
});
